import mss
import numpy as np
import cv2

# Define the screen region to capture (adjust based on your game window)
region = {"top": 420, "left": 3245, "width": 555, "height": 555}

def capture_screen(save_path="images/screenshot.png"):
    with mss.mss() as sct:
        screenshot = sct.grab(region)
        img = np.array(screenshot)[:, :, :3]  # Convert BGRA to BGR

        # Convert to grayscale
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

        # Save the grayscale screenshot
        cv2.imwrite(save_path, gray)
        print(f"Screenshot saved at {save_path}")

if __name__ == "__main__":
    capture_screen() 