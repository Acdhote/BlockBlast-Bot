import cv2
import numpy as np
import mss

def capture_block_pool_region(region, output_path):
    # Create a screen capture object using mss
    with mss.mss() as sct:
        # Capture the specified region of the screen
        screenshot = sct.grab(region)
        
        # Convert the screenshot to a NumPy array (required for OpenCV)
        screenshot_np = np.array(screenshot)

        # Convert the screenshot from RGBA (sct format) to BGR (OpenCV format)
        screenshot_bgr = cv2.cvtColor(screenshot_np, cv2.COLOR_RGBA2BGR)

        # Convert the image to grayscale
        screenshot_gray = cv2.cvtColor(screenshot_bgr, cv2.COLOR_BGR2GRAY)

        # Save the grayscale image
        cv2.imwrite(output_path, screenshot_np)
        print(f"Block pool image saved as {output_path}!")

# Define the region (left, top, width, height)
block_pool_region = {"top": 840, "left": 3100, "width": 800, "height": 200}

# Path where you want to save the image
block_pool_image_path = "images/block_pool.png"

# Capture the block pool region and save it as a grayscale image
capture_block_pool_region(block_pool_region, block_pool_image_path)
