import cv2
import numpy as np

def detect_pieces_dynamic(image_path):
    """
    Detects individual pieces in an image by dynamically dividing them into squares
    based on green contours and stricter overlap checks.
    """
    # Load the image
    block_pool_img = cv2.imread(image_path)
    if block_pool_img is None:
        print("Error loading image!")
        return []

    print(f"Block pool image dimensions: {block_pool_img.shape}")

    # Convert image to grayscale and threshold it
    gray = cv2.cvtColor(block_pool_img, cv2.COLOR_BGR2GRAY)
    thresh = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                   cv2.THRESH_BINARY_INV, 11, 2)

    # Find contours
    contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    print(f"Total contours found: {len(contours)}")

    # Filter contours by size (adjust thresholds as needed)
    filtered_contours = [cnt for cnt in contours if cv2.contourArea(cnt) > 500]

    print(f"Filtered contours: {len(filtered_contours)}")

    # If no filtered contours, return early
    if not filtered_contours:
        print("No valid contours found after filtering")
        return []

    detected_grids = []

    for i, contour in enumerate(filtered_contours):
        # Get bounding box of contour
        x, y, w, h = cv2.boundingRect(contour)

        # Initialize grid
        grid = []

        # Step size (approximate size of one square)
        step_size = 34

        # Horizontal lines
        horizontal_lines = []
        for row in range(y, y + h + 1, step_size):
            horizontal_lines.append(row)

        # Vertical lines
        vertical_lines = []
        for col in range(x, x + w + 1, step_size):
            vertical_lines.append(col)

        # Create grid based on intersections of lines
        for r in range(len(horizontal_lines) - 1):
            grid_row = []
            for c in range(len(vertical_lines) - 1):
                # Calculate cell boundaries
                cell_x_start = vertical_lines[c]
                cell_y_start = horizontal_lines[r]
                cell_x_end = vertical_lines[c + 1]
                cell_y_end = horizontal_lines[r + 1]

                # Extract cell region from binary mask
                cell_region = thresh[cell_y_start:cell_y_end, cell_x_start:cell_x_end]

                # Check if at least 20% of the pixels in the cell are part of the contour
                filled_pixel_ratio = np.sum(cell_region > 0) / (cell_region.shape[0] * cell_region.shape[1])
                if filled_pixel_ratio > 0.2:  # Adjust threshold as needed
                    grid_row.append(1)  # Mark as filled
                else:
                    grid_row.append(0)  # Mark as empty

            grid.append(grid_row)

        # Remove empty rows and columns from the grid
        if len(grid) == 0:
            print(f"Grid for piece {i} is empty")
            continue

        grid = np.array(grid)
        rows_with_content = np.any(grid, axis=1)
        cols_with_content = np.any(grid, axis=0)
        grid = grid[rows_with_content][:, cols_with_content]

        # Save or display debug information
        print(f"Detected grid for piece {i}:")
        for row in grid:
            print(''.join('■' if cell else '□' for cell in row))

        detected_grids.append(grid.tolist())

    return detected_grids
