import cv2
import numpy as np

# Function to capture the game grid from a screenshot
def create_grid(image_path, grid_size=(8, 8), intensity_threshold=80):
    # Load the grayscale image
    img = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)

    # Get image dimensions
    height, width = img.shape

    # Calculate the size of each block by dividing image dimensions by grid size
    block_width = width // grid_size[0]
    block_height = height // grid_size[1]

    # List to store the coordinates of blocks in the grid
    grid = []

    # Iterate through each grid cell
    for row in range(grid_size[1]):
        for col in range(grid_size[0]):
            # Get the coordinates of the current cell
            x1 = col * block_width
            y1 = row * block_height
            x2 = (col + 1) * block_width
            y2 = (row + 1) * block_height

            # Extract the block (sub-image)
            block = img[y1:y2, x1:x2]

            # Calculate the percentage of pixels above the intensity threshold
            block_intensity_percentage = np.sum(block > intensity_threshold) / (block_width * block_height)

            # If more than 50% of the block's pixels are above the threshold, it contains a block
            if block_intensity_percentage > 0.5:
                grid.append((x1, y1, x2, y2))  # Store the coordinates of the block

    # Visualize the grid and detected blocks
    img_color = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)  # Convert grayscale to color for visualization

    # Draw the grid (for reference)
    for row in range(grid_size[1]):
        for col in range(grid_size[0]):
            x1 = col * block_width
            y1 = row * block_height
            x2 = (col + 1) * block_width
            y2 = (row + 1) * block_height
            cv2.rectangle(img_color, (x1, y1), (x2, y2), (0, 0, 255), 1)  # Red grid lines

    # Color the blocks that contain detected objects (green)
    for (x1, y1, x2, y2) in grid:
        cv2.rectangle(img_color, (x1, y1), (x2, y2), (0, 255, 0), -1)  # Green fill for blocks

    # Show the image with the grid and detected blocks

    return grid  # Return the coordinates of the blocks for further processing

# Converts the detected grid into a 2D game state
def convert_to_game_state(grid, grid_size=(8, 8)):
    """
    Converts the detected blocks into a game state (2D grid of 1s and 0s).
    """
    game_state = [[0 for _ in range(grid_size[0])] for _ in range(grid_size[1])]
    for (x1, y1, x2, y2) in grid:
        col = x1 // (x2 - x1)
        row = y1 // (y2 - y1)
        game_state[row][col] = 1
    return game_state

# Simulate the move by placing a block and clearing lines
def simulate_move(game_state, column):
    """
    Simulates placing a piece on the game state.

    Args:
    - game_state (list): The current game state (2D grid).
    - column (int): The column where the block is to be placed.

    Returns:
    - new_game_state (list): The updated game state after the move.
    """
    # Find the lowest empty spot in the specified column
    for row in range(len(game_state)-1, -1, -1):
        if game_state[row][column] == 0:  # Empty spot
            # Place the block here (a single block for simplicity)
            game_state[row][column] = 1
            break  # Exit the loop after placing the block
    
    # After placing the block, clear lines if any are full
    new_game_state = clear_lines(game_state)
    
    return new_game_state

# Clear lines after a block is placed
def clear_lines(game_state):
    """
    Clears full lines and shifts remaining blocks down.

    Args:
    - game_state: Current game state (2D grid).

    Returns:
    - new_game_state: The updated game state after clearing lines.
    """
    new_game_state = []
    for row in game_state:
        if all(cell == 1 for cell in row):  # Check if the row is full
            new_game_state.insert(0, [0] * len(row))  # Add an empty row at the top
        else:
            new_game_state.append(row)  # Keep the row as it is
    
    return new_game_state

# Example usage:
if __name__ == "__main__":
    # Step 1: Capture the game screenshot and create the grid
    screenshot_path = "images/screenshot.png"
    grid = create_grid(screenshot_path)
    game_state = convert_to_game_state(grid)

    # Step 2: Simulate a move (place a block in column 3)
    column_to_place = 2  # Example: column 2 (3rd column)
    new_game_state = simulate_move(game_state, column_to_place)

    # Step 3: Print the new game state after placing the block
    print("New game state after simulated move:")
    for row in new_game_state:
        print(row)
