import numpy as np

import numpy as np

def simulate_piece(game_state, piece, col, row):
    """Simulate placing a piece on the game board."""
    new_state = [r[:] for r in game_state]  # Create a copy of the game state
    piece_array = np.array(piece) if isinstance(piece, list) else piece
    
    for r in range(piece_array.shape[0]):
        for c in range(piece_array.shape[1]):
            if piece_array[r][c] == 1:
                new_row, new_col = row + r, col + c
                print(f"Checking position: ({new_row}, {new_col})")  # Debug print
                
                if 0 <= new_row < len(game_state) and 0 <= new_col < len(game_state[0]):
                    if new_state[new_row][new_col] == 1:
                        print("Collision detected!")  # Debug print
                        return None  # Collision detected
                    else:  # If the cell is empty (0), place the piece
                        new_state[new_row][new_col] = 1
                else:
                    print("Out of bounds!")  # Debug print
                    return None  # Out of bounds
    return new_state



def generate_all_placements(game_state, piece):
    """Generate all valid placements for a given piece."""
    valid_placements = []
    piece_array = np.array(piece) if isinstance(piece, list) else piece
    
    for row in range(len(game_state) - piece_array.shape[0] + 1):
        for col in range(len(game_state[0]) - piece_array.shape[1] + 1):
            new_state = simulate_piece(game_state, piece_array, col, row)
            if new_state:
                valid_placements.append((row, col))
    
    return valid_placements

def print_game_state(game_state):
    """Print a visual representation of the game state."""
    for row in game_state:
        print(' '.join('■' if cell else '□' for cell in row))

def simulate_combined_placements(game_state, pieces):
    """
    Simulate placing multiple pieces together on the game board.
    Returns all valid combined placements as tuples (placement, piece_positions).
    """
    valid_combinations = []

    # Generate all valid placements for each piece
    piece_placements = []
    for piece in pieces:
        piece_placements.append(generate_all_placements(game_state, piece))

    # Iterate through all combinations of placements
    for placement1 in piece_placements[0]:  # Placements for Piece 1
        for placement2 in piece_placements[1]:  # Placements for Piece 2
            for placement3 in piece_placements[2]:  # Placements for Piece 3
                # Simulate placing all three pieces
                new_state = [row[:] for row in game_state]  # Copy the game state
                positions = []  # Store positions of each piece
                
                # Place Piece 1
                new_state = simulate_piece(new_state, pieces[0], placement1[1], placement1[0])
                if new_state is None:
                    continue
                positions.append((placement1[0], placement1[1]))

                # Place Piece 2
                new_state = simulate_piece(new_state, pieces[1], placement2[1], placement2[0])
                if new_state is None:
                    continue
                positions.append((placement2[0], placement2[1]))

                # Place Piece 3
                new_state = simulate_piece(new_state, pieces[2], placement3[1], placement3[0])
                if new_state is None:
                    continue
                positions.append((placement3[0], placement3[1]))

                # Add this combination to valid_combinations
                valid_combinations.append((new_state, positions))

    return valid_combinations

# Example usage (you can keep this commented out if you don't want it to run when importing the module)
"""
# Assuming you have game_state and detected_pieces defined
print("\n=== Simulating Combined Placements ===")
combined_placements = simulate_combined_placements(game_state, detected_pieces)
print(f"Total valid combined placements: {len(combined_placements)}")

# Print one example combined placement
if combined_placements:
    print("\nExample Combined Placement:")
    print_game_state(combined_placements[0])
"""
