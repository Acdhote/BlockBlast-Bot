import numpy as np

def calculate_holes(game_state):
    """Count the number of holes in the game state."""
    holes = 0
    for col in range(len(game_state[0])):
        block_found = False
        for row in range(len(game_state)):
            if game_state[row][col] == 1:
                block_found = True
            elif block_found and game_state[row][col] == 0:
                holes += 1
    return holes

def calculate_blocks_above_holes(game_state):
    """Count the number of blocks above holes."""
    blocks_above = 0
    for col in range(len(game_state[0])):
        hole_found = False
        blocks = 0
        for row in range(len(game_state)-1, -1, -1):  # Start from bottom
            if game_state[row][col] == 0 and not hole_found:
                hole_found = True
            elif hole_found and game_state[row][col] == 1:
                blocks += 1
        blocks_above += blocks
    return blocks_above

def calculate_bumpiness(game_state):
    """Calculate the bumpiness of the game state."""
    heights = [0] * len(game_state[0])
    for col in range(len(game_state[0])):
        for row in range(len(game_state)):
            if game_state[row][col] == 1:
                heights[col] = len(game_state) - row
                break
    return sum(abs(heights[i] - heights[i+1]) for i in range(len(heights)-1))

def calculate_aggregate_height(game_state):
    """Calculate the sum of all column heights."""
    heights = [0] * len(game_state[0])
    for col in range(len(game_state[0])):
        for row in range(len(game_state)):
            if game_state[row][col] == 1:
                heights[col] = len(game_state) - row
                break
    return sum(heights)

def calculate_max_column_height(game_state):
    """Calculate the height of the tallest column."""
    return max(len(game_state) - row for col in range(len(game_state[0])) 
               for row in range(len(game_state)) if game_state[row][col] == 1)

def calculate_well_depths(game_state):
    """Calculate the depths of wells in the game state."""
    heights = [0] * len(game_state[0])
    for col in range(len(game_state[0])):
        for row in range(len(game_state)):
            if game_state[row][col] == 1:
                heights[col] = len(game_state) - row
                break
    
    well_depths = 0
    for i in range(len(heights)):
        if i == 0:
            well_depths += max(0, heights[1] - heights[0] - 1)
        elif i == len(heights) - 1:
            well_depths += max(0, heights[-2] - heights[-1] - 1)
        else:
            well_depths += max(0, min(heights[i-1], heights[i+1]) - heights[i] - 1)
    return well_depths

def calculate_horizontal_lines_cleared(game_state):
    """Calculate the number of horizontal lines cleared in the game state."""
    lines_cleared = 0
    for row in game_state:
        if all(cell == 1 for cell in row):  # A line is cleared if all cells are filled
            lines_cleared += 1
    return lines_cleared

def calculate_vertical_lines_cleared(game_state):
    """Calculate the number of vertical lines cleared in the game state."""
    lines_cleared = 0
    for col in range(len(game_state[0])):
        if all(game_state[row][col] == 1 for row in range(len(game_state))):  # Check all cells in the column
            lines_cleared += 1
    return lines_cleared

def calculate_total_lines_cleared(game_state):
    """Calculate the total number of horizontal and vertical lines cleared."""
    horizontal_lines = calculate_horizontal_lines_cleared(game_state)
    vertical_lines = calculate_vertical_lines_cleared(game_state)
    return horizontal_lines + vertical_lines, horizontal_lines, vertical_lines


def is_perfect_clear(game_state):
    """Check if the game state is a perfect clear (all rows empty)."""
    return all(cell == 0 for row in game_state for cell in row)

def evaluate_board_state(game_state, lines_cleared, combo_streak):
    # Costs
    num_holes = calculate_holes(game_state)
    blocks_above_holes = calculate_blocks_above_holes(game_state)
    bumpiness = calculate_bumpiness(game_state)
    aggregate_height = calculate_aggregate_height(game_state)
    max_column_height = calculate_max_column_height(game_state)
    well_depths = calculate_well_depths(game_state)

    # Rewards
    line_clear_reward = [0, 100, 300, 500, 800] + [1000 * i for i in range(5, 20)]  # Extend rewards for large clears
    combo_reward = combo_streak * 50            # Reward increases with combo streak length
    perfect_clear_reward = 1000 if is_perfect_clear(game_state) else 0

    # Handle large line clears gracefully
    if lines_cleared >= len(line_clear_reward):
        reward_for_lines = line_clear_reward[-1] + (lines_cleared - len(line_clear_reward) + 1) * 500
    else:
        reward_for_lines = line_clear_reward[lines_cleared]

    # Weighted scoring function
    score = (
        -10 * num_holes                  # Penalize holes heavily
        -5 * blocks_above_holes          # Penalize blocks above holes moderately
        -3 * bumpiness                   # Penalize bumpiness moderately
        -2 * aggregate_height            # Penalize overall height lightly
        -1 * max_column_height           # Penalize tall columns lightly
        -4 * well_depths                 # Penalize deep wells moderately
        + reward_for_lines               # Reward based on lines cleared
        + combo_reward                   # Reward combos exponentially
        + perfect_clear_reward           # Huge reward for perfect clears
    )
    
    return score



